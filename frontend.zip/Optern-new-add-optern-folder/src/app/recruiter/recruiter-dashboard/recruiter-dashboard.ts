import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-dashboard',
  standalone: true,
  templateUrl: './recruiter-dashboard.html',
  styleUrls: ['./recruiter-dashboard.css'],
})
export class RecruiterDashboardComponent {}
